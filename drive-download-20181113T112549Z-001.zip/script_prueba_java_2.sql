create database bd_prueba_3_java;

use bd_prueba_3_java;

create table asignatura(
    id int auto_increment,
    nombre varchar(200),
    primary key(id)
);

insert into asignatura values(null, 'Estructuras de programación');
insert into asignatura values(null, 'Programación orientada a objetos');
insert into asignatura values(null, 'Programación Java');

create table nota(
    id int auto_increment,
    valor float,/*Nota en sí*/
    porcentaje float,
    asignatura int,
    primary key(id),
    foreign key(asignatura) references asignatura(id)
);

select * from asignatura;
select * from nota;